ENGLISH:
[Credits]
Source: https://github.com/N0B0DY7198/NovaSec-XV
Fork from NovaSec-XV: SKID-XV
Contact author source: n1x#0666
[Thanks xd]
Thanks N1X, 2x444z, gbao, tcpfox/udpfox, Zeya5sx/Klix Nguyen for help me make "fork" from NovaSec-XV
Contact via Discord: Brutal32#5868 (Unbanned xd)
Contact via Telegram: @tcpfox (the representative for Skid-XV)
Contact my friend: @klixnguyen
[Add some other features to SKID-XV]
Add: Captcha Verification, Gif Support (bruh it's support on banner system), Attack Layer 4/7, ToS command (Term or Service command), Power Proof Uploader (Support only discord webhook xd), plan-running command, profile command and add simple blacklist code

ATTENTION 
100% free source, if you see anyone holding this source to sell, they are SCAM. Hope you don't change Credits

VN:
[Credits]
Nguồn code: https://github.com/N0B0DY7198/NovaSec-XV
Bản "Fork" NovaSec-XV: SKID-XV
Contact chủ source: n1x#0666
[Thanks xd]
Thanks N1X, 2x444z, gbao, tcpfox/udpfox, Zeya5sx/Klix Nguyen vì 1 phần giúp làm bản "fork" từ NovaSec-XV
Liên hệ qua discord: Brutal32#5868
Liên hệ qua telegram: @tcpfox ( Người đại diện cho Skid-XV)
Liên hệ bạn bè của tôi: @klixnguyen
[Thêm 1 số chức năng vào SKID-XV]
Thêm: Xác minh Captcha, Hỗ Trợ Gif (thực ra thì nó được hỗ trợ từ banner system), Attack Layer 4/7, Lệnh ToS (Lệnh hiện Điều Khoản Dịch Vụ), Power Proof Uploader (Chỉ hỗ trợ Discord Webhook), lệnh plan-running, lệnh profile và thêm chức năng blacklist đơn giản 

LƯU Ý
Mã nguồn miễn phí 100%, nếu bạn thấy ai sử dụng mã nguồn này để bán, họ là LỪA ĐẢO. Hy vọng bạn không thay đổi Credits